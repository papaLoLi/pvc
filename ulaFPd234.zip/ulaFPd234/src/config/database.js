module.exports = {
    dialect: 'postgres',
    host: 'drona.db.elephantsql.com (drona-01)',
    username: 'gudcskei',
    password: 'y6FM8Pb-mIfUEIbK2QJFp3lCvm3PeLj7',
    database: 'gudcskei',
    define:{
        timestamps: true,
        underscored: true,
    },

};